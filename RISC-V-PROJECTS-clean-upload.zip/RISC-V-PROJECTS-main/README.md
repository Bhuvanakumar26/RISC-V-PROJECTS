# RISC-V Projects

A collection of digital design, Verilog HDL, SystemVerilog, and RISC-V learning projects.

## Project contents

- ATM design and testbench
- Day 1–4 digital design exercises
- FSM examples
- 4-bit ALU
- Basic 2-stage RISC-V processor
- D flip-flop and 4-bit full adder
- Verilog/SystemVerilog source files, testbenches, documentation, and selected waveform screenshots

## Attribution

Some source files in this repository are adapted or reused from **Adhiind's RISC-V-PROJECTS** repository: https://github.com/Adhiind/RISC-V-PROJECTS . They are included with the author's permission. Original authorship of those files remains with their respective author(s). Please check with the original author for any separate licensing terms before further redistribution.

## Notes

Generated simulator databases, temporary backup files, and local simulator configuration files have been omitted. Re-run the simulations in your HDL simulator to regenerate local build artifacts.
